//Please do not remix this. This is for demonstration purposes only.
onEvent("button2", "click", function( ) {
  setScreen("screen3");
});
onEvent("button1", "click", function( ) {
  setScreen("screen2");
});
onEvent("button7", "click", function( ) {
  if (getText("text_input2") == "CODE123") {
    
  }
});
if (getText("dropdown1") == "Class 1") {
  setScreen("class1login");
} else if ((getText("dropdown1") == "Class 2")) {
  setScreen("class2login");
} else if ((getText("dropdown1") == "Class 3")) {
  setScreen("class3login");
}
